package com.djiman.bugobi.advance34.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pure-native beat grid value object. Deck synchronization normally uses the
 * steady grid stored on AnalysisResult itself; looper/sampler timing may use a
 * separately verified BeatGridData with per-beat timestamps.
 */
public final class BeatGridData {
    public double bpm = 120.0;
    public double beatgridOffset = 0.0;
    public List<Double> beatTimes = Collections.emptyList();
    public boolean gridVariable = false;
    public boolean gridVerified = false;
    public boolean looperOnly = false;
    public String reason = "";

    public BeatGridData() {}

    public BeatGridData(double bpm, double beatgridOffset, List<Double> beatTimes,
                        boolean gridVariable, boolean gridVerified, boolean looperOnly,
                        String reason) {
        this.bpm = bpm;
        this.beatgridOffset = beatgridOffset;
        this.beatTimes = beatTimes == null ? Collections.emptyList() : new ArrayList<>(beatTimes);
        this.gridVariable = gridVariable;
        this.gridVerified = gridVerified;
        this.looperOnly = looperOnly;
        this.reason = reason == null ? "" : reason;
    }

    public BeatGridData copy() {
        return new BeatGridData(bpm, beatgridOffset, beatTimes, gridVariable, gridVerified, looperOnly, reason);
    }

    public boolean isValid() {
        if (!Double.isFinite(bpm) || bpm < 35.0 || bpm > 300.0 || !Double.isFinite(beatgridOffset)) return false;
        if (beatTimes == null || beatTimes.isEmpty()) return looperOnly && gridVerified;
        if (beatTimes.size() < 2 || beatTimes.size() >= 5000) return false;
        double last = Double.NEGATIVE_INFINITY;
        for (double t : beatTimes) {
            if (!Double.isFinite(t) || t <= last) return false;
            last = t;
        }
        return true;
    }

    public static BeatGridData steady(AnalysisResult a, boolean verified, String reason) {
        return new BeatGridData(a.bpm, a.beatgridOffset, Collections.emptyList(), false,
                verified, false, reason);
    }

    public static BeatGridData fromAnalysis(AnalysisResult a, boolean verified, String reason) {
        return new BeatGridData(a.bpm, a.beatgridOffset, a.beatTimes, a.gridVariable,
                verified, false, reason);
    }
}
