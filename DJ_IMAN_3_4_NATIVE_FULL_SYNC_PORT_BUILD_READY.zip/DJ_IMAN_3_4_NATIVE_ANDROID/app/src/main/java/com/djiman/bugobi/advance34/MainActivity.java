package com.djiman.bugobi.advance34;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Toast;

import com.djiman.bugobi.advance34.automix.AutomixController;
import com.djiman.bugobi.advance34.ui.AutomixDialog;
import com.djiman.bugobi.advance34.ui.DjMainView;
import com.djiman.bugobi.advance34.ui.LibraryDialog;
import com.djiman.bugobi.advance34.ui.SettingsDialog;

/**
 * Native mixer host. Access control is intentionally isolated in AccessActivity so
 * this Activity is not loaded until the user has reached the native access screen.
 */
public final class MainActivity extends Activity implements DjMainView.Host {
    private static final int AUDIO_PERMISSION = 44;
    private DjController dj;
    private AutomixController automix;
    private DjMainView view;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        requestAudioAndOpen();
        immersive();
    }

    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private void requestAudioAndOpen() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{permission}, AUDIO_PERMISSION);
        } else {
            openMixer();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == AUDIO_PERMISSION) openMixer();
    }

    private void openMixer() {
        if (dj != null) return;
        try {
            dj = new DjController(this);
            automix = new AutomixController(this, dj);
            view = new DjMainView(this, dj, automix, this);
            setContentView(view);
            immersive();
        } catch (Throwable e) {
            if (dj != null) {
                try { dj.close(); } catch (Throwable ignored) {}
                dj = null;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Audio engine could not start")
                    .setMessage(android.util.Log.getStackTraceString(e))
                    .setPositiveButton("CLOSE", null)
                    .show();
        }
    }

    @Override public void openLibraryForDeck(int deck) { LibraryDialog.show(this, dj, deck == 0 ? "Load Deck A" : "Load Deck B", track -> dj.loadTrack(deck, track)); }
    @Override public void openLibraryGeneral() { LibraryDialog.show(this, dj, "Music Library", track -> new AlertDialog.Builder(this).setTitle(track.title).setItems(new String[]{"LOAD TO DECK A", "LOAD TO DECK B", "ADD TO AUTOMIX"}, (d, w) -> { if (w == 0) dj.loadTrack(0, track); else if (w == 1) dj.loadTrack(1, track); else automix.add(track); }).show()); }
    @Override public void openLooperLoader(int slot) { LibraryDialog.show(this, dj, "Load Loop " + (slot + 1), track -> { Toast.makeText(this, "Analysing loop…", Toast.LENGTH_SHORT).show(); dj.loadLooper(slot, track, () -> Toast.makeText(this, "Loop " + (slot + 1) + " ready — SYNC TO MASTER", Toast.LENGTH_SHORT).show(), e -> Toast.makeText(this, "Loop load failed: " + e.getMessage(), Toast.LENGTH_LONG).show()); }); }
    @Override public void openSampleLoader(int slot) { LibraryDialog.show(this, dj, "Load Sampler Pad " + (slot + 1), track -> { Toast.makeText(this, "Loading sample…", Toast.LENGTH_SHORT).show(); dj.loadSample(slot, track, () -> Toast.makeText(this, "Sampler pad ready", Toast.LENGTH_SHORT).show(), e -> Toast.makeText(this, "Sample load failed: " + e.getMessage(), Toast.LENGTH_LONG).show()); }); }
    @Override public void openAutomix() { AutomixDialog.show(this, dj, automix); }
    @Override public void openSettings() { SettingsDialog.show(this, dj); }

    @Override public void onBackPressed() { if (view != null && view.goBack()) return; super.onBackPressed(); }
    @Override protected void onResume() { super.onResume(); immersive(); }
    @Override protected void onDestroy() { if (automix != null) automix.close(); if (dj != null) dj.close(); super.onDestroy(); }
}
