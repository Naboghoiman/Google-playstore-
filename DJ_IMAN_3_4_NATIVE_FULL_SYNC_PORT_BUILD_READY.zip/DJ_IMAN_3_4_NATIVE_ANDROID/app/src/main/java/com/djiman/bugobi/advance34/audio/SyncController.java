package com.djiman.bugobi.advance34.audio;

import com.djiman.bugobi.advance34.model.DeckState;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Pure-native port of the DJ IMAN 3.4 sync-engine.js timing contract.
 *
 * Deck synchronization deliberately uses the steady deck BPM/offset grid. Any verified
 * variable/kick map is reserved for looper/sampler timing by the analysis pipeline.
 * Scheduling and phase-correction ramps are executed by the AAudio render-frame engine;
 * this Java class only calculates musical targets.
 */
public final class SyncController implements AutoCloseable {
    public enum Mode { TEMPO, BEAT, BAR }
    public enum Quantize { OFF, QUARTER, HALF, BEAT, BAR }

    private static final double[] FAMILY = {1.0, 0.5, 2.0};
    private static final double PHASE_TRIGGER_SEC = 0.002; // original 3.4: 2 ms
    private static final double LOCKED_MS = 6.0;

    private final NativeDjEngine engine;
    private final DeckState a;
    private final DeckState b;
    private final ScheduledExecutorService clock = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "djiman-sync-clock"); t.setDaemon(true); return t;
    });

    private volatile Mode mode = Mode.BAR;
    private volatile Quantize quantize = Quantize.BEAT;
    private volatile int masterDeck = NativeDjEngine.DECK_A;
    private final double[] family = {1.0, 1.0};
    private final Object[] lastTrack = new Object[2];
    private final int[] lastSyncMaster = {-1, -1};
    private final long[] correctionCooldownUntilNs = {0, 0};
    private final long[] startGuardUntilNs = {0, 0};
    private volatile Snapshot snapshot = new Snapshot("A", 0, 0, false);

    public SyncController(NativeDjEngine engine, DeckState a, DeckState b) {
        this.engine = engine; this.a = a; this.b = b;
        clock.scheduleAtFixedRate(this::maintainSafe, 25, 25, TimeUnit.MILLISECONDS);
    }

    public void setMode(Mode value) { mode = value == null ? Mode.BAR : value; }
    public Mode mode() { return mode; }
    public void setQuantize(Quantize value) { quantize = value == null ? Quantize.BEAT : value; }
    public Quantize quantize() { return quantize; }

    public synchronized void setMasterDeck(int deck) {
        int d = deck == NativeDjEngine.DECK_B ? NativeDjEngine.DECK_B : NativeDjEngine.DECK_A;
        masterDeck = d;
        engine.cancelPhaseCorrection(d);
    }

    /**
     * Dynamic-master extension used by DJ IMAN: the only playing deck wins; with both playing,
     * the audible crossfader side wins. At the exact centre, the previous master is retained.
     */
    public synchronized int masterDeck() {
        boolean pa = engine.isPlaying(0), pb = engine.isPlaying(1);
        if (pa != pb) {
            int d = pa ? 0 : 1;
            if (masterDeck != d) setMasterDeck(d);
        } else if (pa) {
            float x = engine.crossfader();
            int d = x < .5f ? 0 : x > .5f ? 1 : masterDeck;
            if (masterDeck != d) setMasterDeck(d);
        }
        return masterDeck;
    }

    public synchronized void syncNow(int targetDeck) {
        int target = targetDeck == 1 ? 1 : 0;
        int other = 1 - target;
        DeckState td = state(target), md = state(other);
        if (!ready(td) || !ready(md)) return;

        // Original behavior: a playing target with the other deck stopped becomes master.
        if (engine.isPlaying(target) && !engine.isPlaying(other)) {
            setMasterDeck(target);
            return;
        }

        // If both are running, preserve DJ IMAN's audible/crossfader master rule.
        if (engine.isPlaying(target) && engine.isPlaying(other)) {
            int audibleMaster = masterDeck();
            if (audibleMaster == target) return;
            other = audibleMaster;
            md = state(other);
        }

        engine.cancelPhaseCorrection(target);
        engine.setPitchBend(target, 0);

        final double lead = Math.max(0.025, engine.outputLatencySeconds());
        final double fam = chooseFamily(target, other);
        final double masterRate = engine.effectivePlaybackRate(other);
        final double targetRate = clamp(md.analysis.bpm * masterRate * fam / td.analysis.bpm, .2, 2.0);
        family[target] = fam;
        engine.setPlaybackRate(target, targetRate);
        td.playbackRate = targetRate;
        if (engine.isPlaying(other)) setMasterDeck(other);
        lastTrack[target] = td.info;
        lastSyncMaster[target] = other;

        if (mode == Mode.TEMPO) return;

        if (!engine.isPlaying(other)) {
            double p = alignedPosition(target, other, engine.position(target), engine.position(other), targetRate, masterRate);
            engine.seek(target, p);
            return;
        }

        final boolean targetAdvancing = engine.isPlaying(target) && !engine.isScheduled(target);
        double delay = lead;
        double masterPosAt = engine.position(other) + lead * masterRate;
        if (!targetAdvancing) {
            // Original family-aware wait: half-time target starts on a wider master boundary.
            double boundaryPeriod = 60.0 / md.analysis.bpm * Math.max(1.0, 1.0 / fam);
            double next = nextBoundary(masterPosAt, md.analysis.beatgridOffset, boundaryPeriod);
            delay += Math.max(0, next - masterPosAt) / Math.max(.2, masterRate);
            masterPosAt = next;
        } else {
            masterPosAt = engine.position(other) + delay * masterRate;
        }

        double targetPosAt = engine.position(target) + (targetAdvancing ? delay * targetRate : 0.0);
        double aligned = alignedPosition(target, other, targetPosAt, masterPosAt, targetRate, masterRate);
        engine.playScheduledAt(target, aligned, delay);
        long now = System.nanoTime();
        startGuardUntilNs[target] = now + (long)((delay + .025) * 1_000_000_000L);
        correctionCooldownUntilNs[target] = startGuardUntilNs[target];
    }

    /** Native equivalent of SyncEngine.togglePlay(). */
    public synchronized void togglePlay(int deck) {
        int d = deck == 1 ? 1 : 0;
        if (engine.isPlaying(d) || engine.isScheduled(d)) {
            engine.pause(d); state(d).playing = false; masterDeck(); return;
        }
        int other = 1 - d;
        if (state(d).syncLocked && engine.isPlaying(other) && mode != Mode.TEMPO) {
            syncNow(d); state(d).playing = true; return;
        }
        double q = quantizedSeek(d, engine.position(d));
        engine.playScheduledAt(d, q, .008); state(d).playing = true;
        startGuardUntilNs[d] = System.nanoTime() + 33_000_000L;
        masterDeck();
    }

    public synchronized double quantizedSeek(int deck, double position) {
        DeckState d = state(deck);
        if (quantize == Quantize.OFF || !ready(d)) return clamp(position, 0, engine.duration(deck));
        double beats = switch (quantize) {
            case QUARTER -> .25;
            case HALF -> .5;
            case BAR -> 4.0;
            default -> 1.0;
        };
        double period = 60.0 / d.analysis.bpm * beats;
        double out = d.analysis.beatgridOffset + Math.rint((position - d.analysis.beatgridOffset) / period) * period;
        return clamp(out, 0, engine.duration(deck));
    }

    public synchronized void setLocked(int deck, boolean locked) {
        DeckState d = state(deck); d.syncLocked = locked;
        if (!locked) engine.cancelPhaseCorrection(deck);
        else syncNow(deck);
    }

    public synchronized void toggleLocked(int deck) { setLocked(deck, !state(deck).syncLocked); }

    /** Manual tempo manipulation releases a slave from lock, matching original 3.4 behavior. */
    public synchronized void operatorTempoChanged(int deck, double rate) {
        int d = deck == 1 ? 1 : 0;
        if (state(d).syncLocked && masterDeck() != d) state(d).syncLocked = false;
        state(d).playbackRate = clamp(rate, .2, 2.0);
        engine.cancelPhaseCorrection(d);
        engine.setPlaybackRate(d, state(d).playbackRate);
        maintain();
    }

    public Snapshot snapshot() { return snapshot; }

    private void maintainSafe() { try { maintain(); } catch (Throwable ignored) {} }

    private synchronized void maintain() {
        int master = masterDeck();
        int slave = 1 - master;
        DeckState sd = state(slave), md = state(master);
        if (!sd.syncLocked || !engine.isPlaying(slave) || !engine.isPlaying(master) || !ready(sd) || !ready(md)) return;

        if (lastTrack[slave] != sd.info || lastSyncMaster[slave] != master) { syncNow(slave); return; }

        double masterRate = engine.playbackRate(master) * (1.0 + engine.pitchBend(master));
        double desired = md.analysis.bpm * masterRate * family[slave] / sd.analysis.bpm;
        if (desired < .2 || desired > 2.0) return;
        if (Math.abs(engine.playbackRate(slave) - desired) > 1e-7) {
            if (engine.isScheduled(slave)) { syncNow(slave); return; }
            engine.setPlaybackRate(slave, desired); sd.playbackRate = desired;
        }

        if (mode == Mode.TEMPO || Math.abs(engine.pitchBend(slave)) > 1e-5 || engine.isScratching(slave)) {
            updateSnapshot(master, slave, desired, masterRate, 0);
            return;
        }

        long now = System.nanoTime();
        if (now < startGuardUntilNs[slave] || now < correctionCooldownUntilNs[slave] || engine.phaseCorrectionRemaining(slave) > 0) return;

        double cycle = cycle(slave, master, desired, masterRate);
        double slaveWall = (engine.position(slave) - sd.analysis.beatgridOffset) / desired;
        double masterWall = (engine.position(master) - md.analysis.beatgridOffset) / masterRate;
        // Same sign as original: master wall clock minus slave wall clock.
        double error = wrap(masterWall - slaveWall, cycle);
        updateSnapshot(master, slave, desired, masterRate, error);
        if (Math.abs(error) > PHASE_TRIGGER_SEC) {
            double duration = Math.max(.5, 120.0 / (md.analysis.bpm * masterRate));
            engine.correctPhase(slave, error, duration);
            correctionCooldownUntilNs[slave] = now + (long)((duration + .030) * 1_000_000_000L);
        }
    }

    private void updateSnapshot(int master, int slave, double slaveRate, double masterRate, double knownError) {
        DeckState sd=state(slave), md=state(master);
        double masterBpm=md.analysis.bpm*masterRate;
        double slaveBpm=sd.analysis.bpm*slaveRate/Math.max(1e-9,family[slave]);
        double tempoDiff=Math.abs(masterBpm-slaveBpm);
        double error=knownError;
        if (!Double.isFinite(error) || (knownError==0 && mode!=Mode.TEMPO)) {
            double c=cycle(slave,master,slaveRate,masterRate);
            error=wrap((engine.position(master)-md.analysis.beatgridOffset)/masterRate-(engine.position(slave)-sd.analysis.beatgridOffset)/slaveRate,c);
        }
        snapshot=new Snapshot(master==0?"A":"B",error*1000.0,tempoDiff,
                engine.isPlaying(0)&&engine.isPlaying(1)&&Math.abs(error)*1000.0<LOCKED_MS&&tempoDiff<.05);
    }

    private double chooseFamily(int target, int master) {
        DeckState td=state(target), md=state(master);
        double currentAudible=td.analysis.bpm*engine.playbackRate(target);
        double masterAudible=md.analysis.bpm*engine.effectivePlaybackRate(master);
        double best=1.0,score=Double.POSITIVE_INFINITY;
        for(double f:FAMILY){
            double rate=masterAudible*f/td.analysis.bpm;
            if(rate<.2||rate>2)continue;
            double s=Math.abs(Math.log(Math.max(1e-9,masterAudible*f)/Math.max(1e-9,currentAudible)));
            if(s<score){score=s;best=f;}
        }
        return best;
    }

    private double cycle(int target,int master,double targetRate,double masterRate){
        double beats=mode==Mode.BEAT?1.0:4.0;
        return Math.max(beats*60.0/state(target).analysis.bpm/targetRate,
                beats*60.0/state(master).analysis.bpm/masterRate);
    }

    private double alignedPosition(int target,int master,double targetPos,double masterPos,double targetRate,double masterRate){
        DeckState td=state(target),md=state(master);
        double c=cycle(target,master,targetRate,masterRate);
        double targetCycleSource=c*targetRate, masterCycleSource=c*masterRate;
        double until=(nextBoundary(masterPos,md.analysis.beatgridOffset,masterCycleSource)-masterPos)/masterRate;
        double p=nextBoundary(targetPos,td.analysis.beatgridOffset,targetCycleSource)-until*targetRate;
        if(p<targetPos-.3*targetCycleSource)p+=targetCycleSource;
        if(p<0)p+=targetCycleSource;
        double duration=engine.duration(target);
        while(p>=duration && p-targetCycleSource>=0)p-=targetCycleSource;
        return clamp(p,0,Math.max(0,duration-1e-6));
    }

    private DeckState state(int deck){return deck==1?b:a;}
    private static boolean ready(DeckState d){return d!=null&&d.analysis!=null&&Double.isFinite(d.analysis.bpm)&&d.analysis.bpm>0;}
    private static double nextBoundary(double position,double offset,double interval){
        if(!Double.isFinite(interval)||interval<=0)return position;
        return offset+Math.ceil((position-offset)/interval-1e-10)*interval;
    }
    private static double wrap(double x,double n){return mod(x+n/2.0,n)-n/2.0;}
    private static double mod(double x,double n){return (x%n+n)%n;}
    private static double clamp(double x,double lo,double hi){return Math.max(lo,Math.min(hi,x));}

    @Override public void close(){clock.shutdownNow();}

    public static final class Snapshot {
        public final String masterDeckId;
        public final double phaseErrorMs;
        public final double tempoDifferenceBpm;
        public final boolean locked;
        public Snapshot(String masterDeckId,double phaseErrorMs,double tempoDifferenceBpm,boolean locked){
            this.masterDeckId=masterDeckId;this.phaseErrorMs=phaseErrorMs;this.tempoDifferenceBpm=tempoDifferenceBpm;this.locked=locked;
        }
    }
}
