package com.djiman.bugobi.advance34.analysis;

import com.djiman.bugobi.advance34.model.AnalysisResult;
import com.djiman.bugobi.advance34.model.BeatGridData;
import java.util.List;

/** Native equivalent of sync-upgrade.js beatAt/timeAt/bpmAt/nextTime. */
public final class BeatGridMath {
    private BeatGridMath() {}

    public static double beatAt(AnalysisResult g,double time){
        return beatAt(g==null?120:g.bpm,g==null?0:g.beatgridOffset,g==null?null:g.beatTimes,time);
    }
    public static double timeAt(AnalysisResult g,double beat){
        return timeAt(g==null?120:g.bpm,g==null?0:g.beatgridOffset,g==null?null:g.beatTimes,beat);
    }
    public static double bpmAt(AnalysisResult g,double time){
        return bpmAt(g==null?120:g.bpm,g==null?0:g.beatgridOffset,g==null?null:g.beatTimes,time);
    }
    public static double nextTime(AnalysisResult g,double time,double multiple){
        double b=beatAt(g,time),m=Math.max(1e-6,multiple);return timeAt(g,Math.ceil(b/m-1e-9)*m);
    }

    public static double beatAt(BeatGridData g,double time){
        return beatAt(g==null?120:g.bpm,g==null?0:g.beatgridOffset,g==null?null:g.beatTimes,time);
    }
    public static double timeAt(BeatGridData g,double beat){
        return timeAt(g==null?120:g.bpm,g==null?0:g.beatgridOffset,g==null?null:g.beatTimes,beat);
    }
    public static double bpmAt(BeatGridData g,double time){
        return bpmAt(g==null?120:g.bpm,g==null?0:g.beatgridOffset,g==null?null:g.beatTimes,time);
    }
    public static double nextTime(BeatGridData g,double time,double multiple){
        double b=beatAt(g,time),m=Math.max(1e-6,multiple);return timeAt(g,Math.ceil(b/m-1e-9)*m);
    }

    /** Matches sync-upgrade.js looperGridFor(): only a verified timing map may override the deck grid. */
    public static BeatGridData looperGridFor(AnalysisResult a){
        if(a==null)return null;
        if(a.looperGrid!=null && a.looperGrid.gridVerified && a.looperGrid.isValid())return a.looperGrid;
        return new BeatGridData(a.bpm,a.beatgridOffset,a.beatTimes,a.gridVariable,a.gridVerified,false,a.gridReason);
    }

    private static double beatAt(double bpm,double offset,List<Double>a,double time){
        if(a==null||a.size()<2)return (time-offset)*bpm/60.0;
        int last=a.size()-1;
        if(time<=a.get(0)){double p=a.get(1)-a.get(0);return Math.abs(p)>1e-9?(time-a.get(0))/p:0;}
        if(time>=a.get(last)){double p=a.get(last)-a.get(last-1);return last+(Math.abs(p)>1e-9?(time-a.get(last))/p:0);}
        int lo=0,hi=last;while(hi-lo>1){int mid=(lo+hi)>>>1;if(a.get(mid)<=time)lo=mid;else hi=mid;}
        double p=a.get(lo+1)-a.get(lo);return lo+(Math.abs(p)>1e-9?(time-a.get(lo))/p:0);
    }
    private static double timeAt(double bpm,double offset,List<Double>a,double beat){
        if(a==null||a.size()<2)return offset+beat*60.0/bpm;
        if(beat<0){double p=a.get(1)-a.get(0);return a.get(0)+beat*p;}
        int last=a.size()-1;if(beat>=last){double p=a.get(last)-a.get(last-1);return a.get(last)+(beat-last)*p;}
        int i=Math.max(0,Math.min(a.size()-2,(int)Math.floor(beat)));return a.get(i)+(beat-i)*(a.get(i+1)-a.get(i));
    }
    private static double bpmAt(double bpm,double offset,List<Double>a,double time){
        if(a==null||a.size()<2)return bpm;double b=beatAt(bpm,offset,a,time);int i=Math.max(0,Math.min(a.size()-2,(int)Math.floor(b)));double p=a.get(i+1)-a.get(i);return Math.abs(p)>1e-9?60.0/p:bpm;
    }
}
