package com.djiman.bugobi.advance34.analysis;

import android.content.Context;
import android.content.SharedPreferences;

import com.djiman.bugobi.advance34.model.AnalysisResult;
import com.djiman.bugobi.advance34.model.BeatGridData;
import com.djiman.bugobi.advance34.model.TrackInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Android SharedPreferences replacement for sync-upgrade.js localStorage grid edits. */
public final class GridEditStore {
    private final SharedPreferences prefs;

    public GridEditStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences("djiman.native.grid.edits", Context.MODE_PRIVATE);
    }

    private static String key(TrackInfo info) {
        String stable = info == null ? "unknown" : info.stableKey();
        return "g." + Long.toHexString(info == null ? -1 : info.id) + "." + Integer.toHexString(stable.hashCode());
    }

    public AnalysisResult applySaved(TrackInfo info, AnalysisResult automatic) {
        if (automatic == null) return null;
        String k = key(info);
        if (!prefs.getBoolean(k + ".valid", false)) return automatic;
        double bpm = getDouble(k + ".bpm", automatic.bpm);
        double offset = getDouble(k + ".offset", automatic.beatgridOffset);
        if (!Double.isFinite(bpm) || bpm < 35 || bpm > 300 || !Double.isFinite(offset)) return automatic;
        AnalysisResult out = automatic.copy();
        out.bpm = bpm;
        out.beatgridOffset = offset;
        out.beatTimes = Collections.emptyList();
        out.gridVariable = false;
        out.gridVerified = true;
        out.manualGrid = true;
        String times = prefs.getString(k + ".looperTimes", "");
        double lbpm = getDouble(k + ".looperBpm", Double.NaN);
        double loffset = getDouble(k + ".looperOffset", Double.NaN);
        boolean lverified = prefs.getBoolean(k + ".looperVerified", false);
        boolean lonly = prefs.getBoolean(k + ".looperOnly", false);
        List<Double> parsed = parseTimes(times);
        BeatGridData g = new BeatGridData(lbpm, loffset, parsed, parsed.size() > 1, lverified, lonly, "manual-grid");
        out.looperGrid = g.isValid() ? g : null;
        out.gridReason = "manual-grid";
        return out;
    }

    public void save(TrackInfo info, AnalysisResult edited) {
        if (edited == null || info == null) return;
        String k = key(info);
        SharedPreferences.Editor e = prefs.edit()
                .putBoolean(k + ".valid", true)
                .putLong(k + ".bpm", Double.doubleToRawLongBits(edited.bpm))
                .putLong(k + ".offset", Double.doubleToRawLongBits(edited.beatgridOffset));
        BeatGridData g = edited.looperGrid;
        if (g != null && g.isValid()) {
            e.putLong(k + ".looperBpm", Double.doubleToRawLongBits(g.bpm))
                    .putLong(k + ".looperOffset", Double.doubleToRawLongBits(g.beatgridOffset))
                    .putBoolean(k + ".looperVerified", g.gridVerified)
                    .putBoolean(k + ".looperOnly", g.looperOnly)
                    .putString(k + ".looperTimes", encodeTimes(g.beatTimes));
        } else {
            e.remove(k + ".looperBpm").remove(k + ".looperOffset").remove(k + ".looperVerified")
                    .remove(k + ".looperOnly").remove(k + ".looperTimes");
        }
        e.apply();
    }

    public void clear(TrackInfo info) {
        if (info == null) return;
        String k = key(info);
        prefs.edit().remove(k + ".valid").remove(k + ".bpm").remove(k + ".offset")
                .remove(k + ".looperBpm").remove(k + ".looperOffset").remove(k + ".looperVerified")
                .remove(k + ".looperOnly").remove(k + ".looperTimes").apply();
    }

    public AnalysisResult beatHere(AnalysisResult in, double position) {
        AnalysisResult out = manualCopy(in);
        double beat = Math.rint(BeatGridMath.beatAt(out, position));
        double delta = position - BeatGridMath.timeAt(out, beat);
        out.beatgridOffset += delta;
        if (out.looperGrid != null && out.looperGrid.isValid()) {
            BeatGridData g = out.looperGrid.copy();
            g.beatgridOffset += delta;
            if (g.beatTimes != null && !g.beatTimes.isEmpty()) {
                ArrayList<Double> shifted = new ArrayList<>(g.beatTimes.size());
                for (double t : g.beatTimes) shifted.add(t + delta);
                g.beatTimes = shifted;
            }
            out.looperGrid = g;
        }
        return out;
    }

    public AnalysisResult scaleBpm(AnalysisResult in, double factor) {
        AnalysisResult out = manualCopy(in);
        double next = out.bpm * factor;
        if (!Double.isFinite(next) || next < 35 || next > 300) return in;
        out.bpm = next;
        if (out.looperGrid != null && out.looperGrid.isValid()) {
            BeatGridData g = out.looperGrid.copy();
            g.bpm *= factor;
            if (g.beatTimes != null && g.beatTimes.size() > 1) {
                int count = (int)Math.floor((g.beatTimes.size() - 1) * factor) + 1;
                ArrayList<Double> resampled = new ArrayList<>(Math.max(0, count));
                for (int i=0;i<count;i++) resampled.add(BeatGridMath.timeAt(g, i / factor));
                g.beatTimes = resampled;
                g.gridVariable = resampled.size() > 1;
            }
            out.looperGrid = g.isValid() ? g : null;
        }
        return out;
    }

    public AnalysisResult setBpm(AnalysisResult in, double bpm) {
        if (!Double.isFinite(bpm) || bpm < 35 || bpm > 300) return in;
        AnalysisResult out = manualCopy(in);
        out.bpm = bpm;
        // Matches sync-upgrade.js: arbitrary BPM invalidates the separately tracked looper map.
        out.looperGrid = null;
        return out;
    }

    private static AnalysisResult manualCopy(AnalysisResult in) {
        AnalysisResult out = in.copy();
        out.beatTimes = Collections.emptyList();
        out.gridVariable = false;
        out.gridVerified = true;
        out.manualGrid = true;
        out.gridReason = "manual-grid";
        return out;
    }

    private double getDouble(String key, double fallback) {
        if (!prefs.contains(key)) return fallback;
        return Double.longBitsToDouble(prefs.getLong(key, Double.doubleToRawLongBits(fallback)));
    }

    private static String encodeTimes(List<Double> times) {
        if (times == null || times.isEmpty()) return "";
        StringBuilder b = new StringBuilder(times.size() * 9);
        for (int i=0;i<times.size();i++) {
            if (i>0) b.append(',');
            b.append(Double.toString(times.get(i)));
        }
        return b.toString();
    }

    private static List<Double> parseTimes(String encoded) {
        if (encoded == null || encoded.isEmpty()) return Collections.emptyList();
        String[] parts = encoded.split(",");
        if (parts.length < 2 || parts.length >= 5000) return Collections.emptyList();
        ArrayList<Double> out = new ArrayList<>(parts.length);
        double last = Double.NEGATIVE_INFINITY;
        try {
            for (String p : parts) {
                double v = Double.parseDouble(p);
                if (!Double.isFinite(v) || v <= last) return Collections.emptyList();
                out.add(v); last = v;
            }
            return out;
        } catch (RuntimeException ex) {
            return Collections.emptyList();
        }
    }
}
