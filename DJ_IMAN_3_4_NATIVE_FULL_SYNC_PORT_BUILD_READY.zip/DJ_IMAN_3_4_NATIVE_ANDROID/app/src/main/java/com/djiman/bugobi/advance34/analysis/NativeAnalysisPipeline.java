package com.djiman.bugobi.advance34.analysis;

import com.djiman.bugobi.advance34.model.AnalysisResult;
import com.djiman.bugobi.advance34.model.BeatGridData;
import com.djiman.bugobi.advance34.model.PcmTrack;

import java.util.Collections;

/**
 * Native replacement for the 3.4 hybrid analysis worker. The deck receives a
 * deliberately steady BPM/offset grid. A separately verified variable/kick map
 * is retained for the looper/sampler/rhythm clock only.
 */
public final class NativeAnalysisPipeline {
    private NativeAnalysisPipeline() {}

    public static AnalysisResult analyze(PcmTrack pcm) {
        AnalysisResult advanced = BeatAnalyzer.analyze(pcm);
        AnalysisResult steady = GridRefiner.refine(pcm, advanced);

        // Preserve a trusted sustained-tempo map before the deck grid is flattened.
        BeatGridData variable = null;
        if (advanced.beatTimes != null && advanced.beatTimes.size() > 1
                && advanced.gridVariable && advanced.bpmConfidence >= 0.65) {
            variable = BeatGridData.fromAnalysis(advanced, true, "verified-variable-grid");
        }

        AnalysisResult out = steady.copy();
        out.gridVerified = isTrustedSteady(steady);
        out.looperGrid = variable;

        // The 3.4 sync-upgrade deliberately strips beatTimes from deck transport.
        out.beatTimes = Collections.emptyList();
        out.gridVariable = false;

        // For steady songs a bass/kick map is allowed to override only looper timing.
        if (out.looperGrid == null) {
            BeatGridData kick = LooperKickGrid.analyze(pcm, out);
            if (kick != null) out.looperGrid = kick;
        }
        // If no special map is justified, the verified steady grid is the common reference.
        if (out.looperGrid == null && out.gridVerified) {
            out.looperGrid = BeatGridData.steady(out, true, "steady-grid-reference");
        }
        return out;
    }

    private static boolean isTrustedSteady(AnalysisResult a) {
        if (a == null || !Double.isFinite(a.bpm) || a.bpm < 35 || a.bpm > 300 || !Double.isFinite(a.beatgridOffset)) return false;
        if ("refined-steady-grid".equals(a.gridReason)) return a.bpmConfidence >= .60 && a.gridFitRmsMs <= 28;
        return a.bpmConfidence >= .72 && a.gridFitRmsMs <= 22;
    }
}
