package com.djiman.bugobi.advance34;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.djiman.bugobi.advance34.util.AccessManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lightweight launcher/access gate. Deliberately does not reference the DJ engine,
 * mixer View, beat analysis or synchronization classes, so the app can always
 * reach its opening-code screen before any audio/native subsystem is loaded.
 */
public final class AccessActivity extends Activity {
    private AccessManager access;
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "djiman-access");
        t.setDaemon(true);
        return t;
    });

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            access = new AccessManager(this);
            if (access.restored()) launchMixer();
            else showAccessGate();
            immersive();
        } catch (Throwable error) {
            showStartupFailure(error);
        }
    }

    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private void showAccessGate() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(42, 120, 42, 40);
        root.setBackgroundColor(Color.rgb(6, 9, 12));

        TextView title = new TextView(this);
        title.setText("DJ IMAN");
        title.setTextColor(Color.WHITE);
        title.setTextSize(44);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("PRIVATE PERFORMANCE BUILD\nEnter your opening code to unlock the mixer.");
        sub.setTextColor(Color.LTGRAY);
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 18, 0, 28);
        root.addView(sub);

        EditText code = new EditText(this);
        code.setHint("OPENING CODE");
        code.setSingleLine(true);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        code.setTextColor(Color.WHITE);
        code.setHintTextColor(Color.GRAY);
        root.addView(code, new LinearLayout.LayoutParams(-1, -2));

        CheckBox remember = new CheckBox(this);
        remember.setText("Remember access on this device");
        remember.setTextColor(Color.LTGRAY);
        root.addView(remember);

        Button open = new Button(this);
        open.setText("UNLOCK DJ IMAN");
        root.addView(open, new LinearLayout.LayoutParams(-1, -2));

        TextView status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 16, 0, 0);
        root.addView(status);

        Runnable[] updateBlock = new Runnable[1];
        updateBlock[0] = () -> {
            int seconds = access.remainingSeconds();
            if (seconds > 0) {
                open.setEnabled(false);
                open.setText("TRY AGAIN IN " + seconds + "s");
                status.setText("Too many attempts. Please wait.");
                root.postDelayed(updateBlock[0], 1000);
            } else {
                open.setText("UNLOCK DJ IMAN");
                open.setEnabled(true);
            }
        };

        open.setOnClickListener(v -> {
            if (access.remainingSeconds() > 0) {
                updateBlock[0].run();
                return;
            }
            open.setEnabled(false);
            open.setText("CHECKING CODE…");
            status.setTextColor(Color.LTGRAY);
            status.setText("Checking your opening code…");
            String entered = code.getText().toString();
            boolean keep = remember.isChecked();
            worker.execute(() -> {
                try {
                    access.redeem(entered, keep);
                    runOnUiThread(this::launchMixer);
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        status.setTextColor(Color.rgb(255, 95, 95));
                        status.setText(e.getMessage());
                        updateBlock[0].run();
                    });
                }
            });
        });

        setContentView(root);
        updateBlock[0].run();
    }

    private void launchMixer() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void showStartupFailure(Throwable error) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 60, 32, 32);
        root.setBackgroundColor(Color.rgb(8, 8, 10));

        TextView title = new TextView(this);
        title.setText("DJ IMAN STARTUP ERROR");
        title.setTextColor(Color.RED);
        title.setTextSize(24);
        root.addView(title);

        TextView details = new TextView(this);
        details.setText(android.util.Log.getStackTraceString(error));
        details.setTextColor(Color.WHITE);
        details.setTextSize(13);
        details.setTextIsSelectable(true);
        root.addView(details);

        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); immersive(); }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
