package com.djiman.bugobi.advance34.analysis;

import com.djiman.bugobi.advance34.model.AnalysisResult;
import com.djiman.bugobi.advance34.model.BeatGridData;
import com.djiman.bugobi.advance34.model.PcmTrack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Native port of the 3.4 looper-only bass/kick phase tracker. It deliberately
 * does not replace the deck synchronization grid. A map is published only when
 * several independent song sections agree and the phase drift is large enough
 * to justify a looper-only correction.
 */
public final class LooperKickGrid {
    private LooperKickGrid() {}

    private static final class Peak {
        final double time, weight, bass;
        Peak(double time,double weight,double bass){this.time=time;this.weight=weight;this.bass=bass;}
    }
    private static final class Section {
        final double time, phase, score; final int hits;
        Section(double time,double phase,double score,int hits){this.time=time;this.phase=phase;this.score=score;this.hits=hits;}
    }
    private static final class Shift {
        final double time, shift;
        Shift(double time,double shift){this.time=time;this.shift=shift;}
    }

    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
    private static double mod(double x,double n){return (x%n+n)%n;}
    private static double wrap(double x,double n){return mod(x+n*.5,n)-n*.5;}

    public static BeatGridData analyze(PcmTrack pcm, AnalysisResult base){
        if(pcm==null||base==null||!Double.isFinite(base.bpm)||base.bpm<35||base.bpm>300||!Double.isFinite(base.beatgridOffset))return null;
        final int sr=pcm.sampleRate, frames=pcm.stereo.length/2;
        final double duration=frames/(double)sr;
        if(duration<20)return null;
        List<Peak> peaks=extractBassPeaks(pcm);
        if(peaks.size()<24)return null;

        final double sectionLength=clamp(duration/18.0,6.0,10.0), period=60.0/base.bpm;
        ArrayList<Section> sections=new ArrayList<>();
        for(double start=0;start<duration;start+=sectionLength){
            double end=Math.min(duration,start+sectionLength);
            ArrayList<Peak> local=new ArrayList<>();
            for(Peak p:peaks)if(p.time>=start&&p.time<end&&p.bass>0)local.add(p);
            if(local.size()<8)continue;
            final int bins=96;double[] hist=new double[bins];ArrayList<double[]> events=new ArrayList<>();
            for(Peak p:local){
                // Preserve a trusted steady deck phase unless the bass evidence stays very close to it.
                if(base.gridVerified&&Math.abs(wrap(BeatGridMath.beatAt(base,p.time),1.0))*period>Math.min(.025,period*.07))continue;
                double w=p.weight*Math.sqrt(Math.min(8.0,p.bass));
                if(!Double.isFinite(w)||w<=.1)continue;
                double beat=BeatGridMath.beatAt(base,p.time),phase=mod(beat,1.0),at=phase*bins;
                events.add(new double[]{p.time,w,at});
                double sigma=Math.max(.75,.026/period*bins);
                int floor=(int)Math.floor(at);
                for(int step=-6;step<=6;step++){
                    double dist=wrap(step-(at-floor),bins);int i=(floor+step+bins)%bins;
                    hist[i]+=w*Math.exp(-.5*Math.pow(dist/sigma,2));
                }
            }
            if(events.size()<8)continue;
            double best=0,second=0;int index=0;
            for(int i=0;i<bins;i++)if(hist[i]>best){best=hist[i];index=i;}
            int outside=(int)Math.ceil(.07/period*bins);
            for(int i=0;i<bins;i++)if(Math.abs(wrap(i-index,bins))>outside)second=Math.max(second,hist[i]);
            ArrayList<double[]> support=new ArrayList<>();
            for(double[] e:events)if(Math.abs(wrap(e[2]-index,bins))*period/bins<Math.min(.1,period*.2))support.add(e);
            if(support.size()<4||best<second*1.23||best<5)continue;
            double middle=(start+end)*.5,sx=0,sy=0,sxx=0,sxy=0,sw=0;
            for(double[] e:support){double x=e[0]-middle,y=wrap(e[2]-index,bins)/(double)bins*period,w=e[1];sx+=x*w;sy+=y*w;sxx+=x*x*w;sxy+=x*y*w;sw+=w;}
            if(sw<=0)continue;
            double den=sw*sxx-sx*sx,slope=den!=0?clamp((sw*sxy-sx*sy)/den,-.04,.04):0;
            double phase=wrap(index/(double)bins*period+(sy-slope*sx)/sw,period);
            sections.add(new Section(middle,phase,best/(second+1e-6),support.size()));
        }
        int total=(int)Math.ceil(duration/sectionLength);
        if(sections.size()<3||sections.size()<Math.ceil(total*.45))return null;

        ArrayList<Shift> shifts=new ArrayList<>();
        for(Section s:sections){
            double phase=s.phase;
            if(!shifts.isEmpty()){
                double prior=shifts.get(shifts.size()-1).shift;
                phase+=Math.rint((prior-phase)/period)*period;
                if(Math.abs(phase-prior)>Math.min(period*.47,sectionLength*.045))return null;
            }
            shifts.add(new Shift(s.time,phase));
        }

        double firstOrigin=BeatGridMath.timeAt(base,0),first=firstOrigin+deltaAt(shifts,firstOrigin,sectionLength),index=0;
        while(first<0&&index<6){index++;double origin=BeatGridMath.timeAt(base,index);first=origin+deltaAt(shifts,origin,sectionLength);}
        if(first<0)return null;
        ArrayList<Double> times=new ArrayList<>();
        int max=(int)Math.ceil(duration/period*2+12);
        while(index<max){
            double origin=BeatGridMath.timeAt(base,index),next=origin+deltaAt(shifts,origin,sectionLength);
            if(next>duration+period)break;
            if(!times.isEmpty()){
                double spacing=next-times.get(times.size()-1);
                if(spacing<period*.75||spacing>period*1.3)return null;
            }
            times.add(next);index++;
        }
        if(times.size()<12)return null;
        double maxShift=Double.NEGATIVE_INFINITY,minShift=Double.POSITIVE_INFINITY;
        ArrayList<Double> contrasts=new ArrayList<>();
        for(Section s:sections){maxShift=Math.max(maxShift,s.phase);minShift=Math.min(minShift,s.phase);contrasts.add(s.score);}
        if(Math.max(Math.abs(maxShift),Math.abs(minShift))<.012&&maxShift-minShift<.012)return null;
        Collections.sort(contrasts);double contrast=contrasts.get(contrasts.size()/2);
        BeatGridData g=new BeatGridData(base.bpm,times.get(0),times,maxShift-minShift>.025,true,false,
                "verified-kick-map sections="+sections.size()+"/"+total+" contrast="+String.format(java.util.Locale.US,"%.2f",contrast)+" driftMs="+Math.round((maxShift-minShift)*1000));
        return g.isValid()?g:null;
    }

    private static double deltaAt(List<Shift> shifts,double time,double sectionLength){
        if(shifts.size()==1)return shifts.get(0).shift;
        if(time<=shifts.get(0).time){Shift a=shifts.get(0),b=shifts.get(1);double slope=clamp((b.shift-a.shift)/(b.time-a.time),-.04,.04);return a.shift+(time-a.time)*slope;}
        for(int i=1;i<shifts.size();i++)if(time<shifts.get(i).time){Shift a=shifts.get(i-1),b=shifts.get(i);double f=(time-a.time)/(b.time-a.time);return a.shift+(b.shift-a.shift)*f;}
        Shift b=shifts.get(shifts.size()-1),a=shifts.get(Math.max(0,shifts.size()-2));
        if(shifts.size()<3){double slope=clamp((b.shift-a.shift)/(b.time-a.time),-.04,.04);return b.shift+slope*clamp(time-b.time,0,sectionLength*3);}
        Shift c=shifts.get(shifts.size()-3);double recent=(b.shift-a.shift)/(b.time-a.time),prior=(a.shift-c.shift)/(a.time-c.time);
        double acceleration=clamp(2*(recent-prior)/(b.time-c.time),-.003,.003),slope=clamp(recent+acceleration*(b.time-a.time)*.5,-.04,.04),dt=clamp(time-b.time,0,sectionLength*3);
        return b.shift+slope*dt+.5*acceleration*dt*dt;
    }

    /** Low-frequency onset extractor used only for the looper reference map. */
    private static List<Peak> extractBassPeaks(PcmTrack pcm){
        int sr=pcm.sampleRate,frames=pcm.stereo.length/2;
        int block=Math.max(32,(int)Math.round(sr/350.0)); // ~350 Hz envelope resolution.
        int n=Math.max(1,frames/block);double[] power=new double[n],novel=new double[n];
        double alpha=1-Math.exp(-2*Math.PI*180.0/sr),lp=0,last=0,sum=0;
        for(int t=0;t<n;t++){
            double e=0;
            for(int k=0;k<block;k++){
                int i=t*block+k;if(i>=frames)break;double x=(pcm.stereo[i*2]+pcm.stereo[i*2+1])*.5;lp+=alpha*(x-lp);e+=lp*lp;
            }
            double rms=Math.sqrt(e/block);power[t]=rms;novel[t]=Math.max(0,rms-last);last=rms;sum+=novel[t];
        }
        double mean=sum/n,variance=0;for(double v:novel)variance+=(v-mean)*(v-mean);double sd=Math.sqrt(variance/n),threshold=mean+sd*.35;
        int radius=Math.max(1,(int)Math.round(.022*sr/block)),minGap=Math.max(1,(int)Math.round(.105*sr/block));
        ArrayList<Peak> out=new ArrayList<>();int lastIndex=-minGap;
        for(int t=radius;t<n-radius;t++){
            double v=novel[t];if(v<threshold||v<1e-7)continue;boolean top=true;for(int j=1;j<=radius;j++)if(novel[t-j]>v||novel[t+j]>=v){top=false;break;}if(!top)continue;
            double left=novel[t-1],right=novel[t+1],den=2*(2*v-left-right),delta=den>0?clamp((right-left)/den,-.5,.5):0;
            double time=(t+.5+delta)*block/(double)sr,bass=Math.max(power[t],1e-9),weight=Math.sqrt(v/(mean+1e-9));
            Peak p=new Peak(time,weight,bass/(mean+1e-9));
            if(!out.isEmpty()&&t-lastIndex<minGap){Peak prev=out.get(out.size()-1);if(p.weight>prev.weight){out.set(out.size()-1,p);lastIndex=t;}}else{out.add(p);lastIndex=t;}
        }
        out.sort(Comparator.comparingDouble(p->p.time));return out;
    }
}
