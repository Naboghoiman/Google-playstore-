# DJ IMAN 3.4 — Full Native Synchronization Port

This checkpoint replaces the remaining browser/WebAudio synchronization assumptions with Android/Java/C++ timing while preserving the DJ IMAN 3.4 synchronization contract as the reference.

## Native deck synchronization

- 25 ms lock-maintenance cadence.
- BAR is the default synchronization mode; TEMPO and BEAT modes are retained.
- Quantize modes: OFF, 1/4 beat, 1/2 beat, 1 beat and 1 bar.
- Half/double BPM-family selection uses the original candidate family `{1, 0.5, 2}` and selects the valid 0.2x–2.0x target rate requiring the smallest logarithmic rate change.
- Dynamic master extension: the only playing deck is master; with both decks playing, the audible crossfader side is master and the previous master is retained at the exact centre.
- Kick/beat-aligned starts and live-deck repositions are scheduled on the AAudio render-frame clock.
- Phase lock uses the original 2 ms correction trigger and bounded ±2% correction.
- Phase corrections use a native 20 ms attack, plateau and 20 ms release plan instead of Java/UI timers.
- Correction duration follows the original `max(0.5, 120 / audibleMasterBpm)` rule.
- Pitch bend and scratching suspend phase correction; manual tempo changes release a slave sync lock.
- Output latency is estimated from the AAudio stream timestamp and render position for audible-reference operations.

## Native BeatGrid / analysis separation

- `NativeAnalysisPipeline` replaces the hybrid analysis-worker orchestration.
- Deck transport/synchronization deliberately receives a steady BPM + beatgrid-offset clock.
- A separately verified variable/kick timing map is retained for looper/sampler/rhythm timing only.
- `LooperKickGrid` implements sectioned low-frequency onset phase tracking with drift/support/spacing validation.
- Manual HALF, DOUBLE, BEAT HERE, BPM and RESET grid edits are persisted with Android `SharedPreferences` rather than browser `localStorage`.

## Native looper / sampler synchronization

- Looper family matching uses `{1, 0.5, 2}` and retains the chosen family while the master track is stable.
- Looper starts use the verified looper grid, family-aware quantization and AAudio render-frame scheduling.
- Sampler sync uses the same verified looper/reference grid rather than the deck-only steady grid.
- Master handover re-anchors running Groove slots.

## Automix correction

Automix no longer calls immediate `play()` after requesting a synchronized start. It waits until the native scheduled incoming deck is actually rendering before moving the crossfader.

## Runtime web dependency status

`app/src/main` contains no HTML, JavaScript, CSS or WASM runtime files and contains no `android.webkit.WebView`, `JavascriptInterface` or `loadUrl()` implementation. The synchronization runtime is Java/C++/AAudio.

## Verification in this workspace

- Java 17 compile check of the changed synchronization, analysis, controller and Automix sources: PASS (Android framework interfaces supplied by compile-only stubs).
- C++20 syntax check of `native_engine.cpp`: PASS. Host compiler reports only deprecation warnings for legacy atomic `shared_ptr` helper functions.
- JNI audit: 75 Java native declarations / 75 C++ JNI definitions; no missing or extra methods.
- Runtime web-file scan: no `.html`, `.js`, `.css` or `.wasm` files under `app/src/main`.

## What is not claimed by this checkpoint

This workspace does not contain the Android SDK/NDK/Gradle toolchain needed to produce and install the APK locally. Therefore this checkpoint is build-ready source, not a claim of successful device execution or 100-song synchronization validation. The next Android build must be installed on the target phone and tested for startup, AAudio device behavior, latency, underruns and real-song synchronization accuracy.
